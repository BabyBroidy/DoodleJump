def f(x, y):
    k=2
    while k<=x and k<=y:
        if x%k==0 and y%k==0:
            return 1
        k+=1
    return 0
def g(a, b):
    return (f(a, 42)<=(not(f(a, 7)))) or ((a+b)>=25)
for a in range(1000):
    if all(g(x, a)==1 for x in range(1000)):
        print(a)
        break
