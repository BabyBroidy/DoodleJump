for n in range(1, 100):
    if (124+5*n)%(62+6*n)==0:
        print(n)
        break
