from ipaddress import*
k=0
net=ip_network(f'192.168.64.176/255.255.255.240', 0)
for i in net:
    if bin(int(i))[2:].zfill(32).count('1')%2!=0:
        k+=1
print(k)
