from fnmatch import*
s='32?056*6'
k=0
for n in range(2023, 10**10, 2023):
    if fnmatch(str(n), s):
        k+=1
print(k)
