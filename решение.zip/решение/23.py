def f(st, fin):
    if st>fin or st==17: return 0
    if st==fin: return 1
    return f(st+1, fin)+f(st*2, fin)+f(st**2, fin)
print(f(2, 16)*f(16, 65))
