from math import*
n=2040+16
i=ceil(log2(n))
I=ceil(i*325/8)
print(ceil(I*8192/2**10))
