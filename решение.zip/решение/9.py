f=open('9_5д.csv')
k=0
for i in f:
    a=[int(x) for x in i.split(';')]
    d=[x for x in a if a.count(x)==3]
    s=[x for x in a if a.count(x)==1]
    if len(d)==3 and len(s)==3:
        if (sum(s)/3)<=(d[0]*3):
            k+=1
print(k)
