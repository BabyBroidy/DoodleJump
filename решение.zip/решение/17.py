f=open('17_5д.txt')
a=[int(x) for x in f]
b=[x for x in a if x%100==10]
m=max(b)
c=[]
for i in range(len(a)-1):
    if (a[i]%2023)*(a[i+1]%2023)>=m:
        c.append(a[i]+a[i+1])
print(len(c), min(c))
