def f(x):
    if x==0:
        return '0'
    s=''
    while x!=0:
        s=str(x%2)+s
        x=x//2
    return s
for n in range(1, 101):
    r=f(n)
    if r.count('1')%2==0:
        r='10'+r[2:]+'1'
    else:
        r='1'+r[2:]+'11'
    r=int(r, 2)
    if r>100:
        print(n)
        break
