from itertools import*
s='1234560'
a=product(s, repeat=5)
k=0
for i in a:
    x=''.join(i)
    b=x
    b=b.replace('2', '0').replace('4', '0').replace('6', '0')
    if s[0]=='0':
        break
    if x.count('5')==1 and '05' not in s and '50' not in s:
        k+=1
print(k)
