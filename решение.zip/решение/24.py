f=open('24_5д.txt')
s=''
k=0
a=set()
for i in f:
    s+=i
s=s.replace('C', 'B').replace('D', 'B').replace('F', 'B').replace('E', 'A').replace('U', 'A')
s=s.replace('BAB', '*')
for x in range(len(s)):
    if s[x]=='*':
        k+=3
    elif s[x-1]=='*' and s[x]=='A' and s[x+1]=='B':
        k+=2
    elif s[x-1]=='*' and s[x]=='A' and s[x+1]=='*':
        k+=1
    else:
        a.add(k)
        k=0
print(max(a))
