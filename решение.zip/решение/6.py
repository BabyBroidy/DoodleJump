from turtle import*
lt(90)
k=20
tracer(0)
for i in range(10):
    fd(k*10)
    for j in range(2):
        fd(10*k)
        rt(90)
up()
for x in range(-1, 20):
    for y in range(-1, 25):
        goto(x*k, y*k)
        dot(5, 'blue')
